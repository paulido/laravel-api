<p>Bonjour,</p>
<p>Veuillez cliquer sur le lien ci-dessous pour vérifier votre adresse email :</p>
<p><a href="<?php echo e($url); ?>"><?php echo e($url); ?></a></p>
<p>Merci !</p>
<?php /**PATH C:\Users\HP\codes\laravel\events-backend\resources\views/emails/verify-email.blade.php ENDPATH**/ ?>