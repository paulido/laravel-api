
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>
<body>
    <h1>Reset Your Password</h1>
    <p>Click the link below to reset your password:</p>
    <a href="<?php echo e($url); ?>"><?php echo e($url); ?></a>
</body>
</html>
<?php /**PATH C:\Users\HP\codes\laravel\events-backend\resources\views/emails/reset_password.blade.php ENDPATH**/ ?>