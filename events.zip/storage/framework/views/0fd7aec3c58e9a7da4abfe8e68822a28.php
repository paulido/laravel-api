<?php echo e($slot); ?>

<?php /**PATH C:\Users\HP\codes\laravel\events-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>