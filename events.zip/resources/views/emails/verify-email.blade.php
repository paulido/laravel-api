<p>Bonjour,</p>
<p>Veuillez cliquer sur le lien ci-dessous pour vérifier votre adresse email :</p>
<p><a href="{{ $url }}">{{ $url }}</a></p>
<p>Merci !</p>
