# Events

Est une plateforme de gestion des grand évènments.


## Swagger with laravel

php artisan l5-swagger:generate

php artisan route:cache


## Delete and recreate tables and fill them

php artisan migrate:fresh --seed

## Seed a specific seeder

php artisan db:seed --class=<Seeder>

## Genreate laravel model, controller with resource, migration and seeder


php artisan make:model Model_name -cmsr

## Create a migration
### create migration for pivot table reservation_salle
php artisan make:migration create_reservation_salle_table 

