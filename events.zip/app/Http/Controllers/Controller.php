<?php

namespace App\Http\Controllers;
use OpenApi\Annotations as OA;

/**
 * @OA\OpenApi(
 *     @OA\Info(
 *         version="1.0",
 *         title="Plateforme Event API",
 *         description="API de la platforme Event",
 *     )
 * )
 */


abstract class Controller
{
    //
}
